const static int SIZE = 16;
typedef float DTYPE;
extern void insertion_sort(DTYPE A[SIZE]);
