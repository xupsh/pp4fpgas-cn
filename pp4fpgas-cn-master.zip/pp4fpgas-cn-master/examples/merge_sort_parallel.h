const static int SIZE = 16;
const static int STAGES = 4;
typedef float DTYPE;
extern void merge_sort_parallel(DTYPE A[SIZE], DTYPE B[SIZE]);
